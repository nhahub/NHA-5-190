# Milestone 1 — Dataset correction update

## Delivery status

The raw manifest and directory convention are ready in the temporary handoff package. The manifest uses **one row per image**, with object annotations linked separately by `annotation_ids` and `annotation_reference`. It currently contains **85,815 images**: 70,000 Fashion-MNIST, 1,158 Fashionpedia validation, and 14,657 Polyvore Outfits disjoint-validation images. Fashion-MNIST IDs are generated from split and zero-based index because the source provides no image filenames or external IDs. Recommendation for downstream processing: preserve the original dataset, split, index, IDs and filenames recorded in the manifest. [Fashion-MNIST source](https://github.com/zalandoresearch/fashion-mnist) · [Fashionpedia source](https://github.com/cvdfoundation/fashionpedia) · [Polyvore Outfits source](https://huggingface.co/datasets/mvasil/polyvore-outfits)

## Updated decisions

- **Fashionpedia — Provisionally selected:** use for garment boxes, masks, categories and attributes. In the complete local validation JSON, 5,259 of 8,781 annotations contain attributes (**59.89%**), so attribute coverage is **Partial**. The 1,158 validation images range from 415–1,024 px wide and 471–1,024 px high; the most common size is 682×1,024. Public labeled test annotations are **Unavailable**: the official download list provides only test image information. Training annotations must be checked before the decision becomes final. Use 27 main categories for garments; keep 19 apparel-part categories as secondary localized features. [Official project](https://fashionpedia.github.io/home/) · [Official downloads](https://github.com/cvdfoundation/fashionpedia#download)
- **Polyvore Outfits — Selected:** gated access was approved and the disjoint validation parquet was downloaded on **2026-09-21**. It contains 14,657 item images locally. Five images (rows 0–4) were opened; all matched their metadata category and validation outfit membership. Use the current Hugging Face repack size, **4.3 GB**. The older implementation README's 6G value refers to its historical archive. [Current dataset](https://huggingface.co/datasets/mvasil/polyvore-outfits) · [Older implementation](https://github.com/mvasil/fashion-compatibility)
- **Fashion-MNIST — For basic checks only:** use for loader, preprocessing and simple classification checks. Its ten classes do not map directly to Fashionpedia or DeepFashion, so no category mapping is planned. [Official repository](https://github.com/zalandoresearch/fashion-mnist)
- **DeepFashion-MultiModal — Backup:** this is separate from the original DeepFashion benchmarks. The original release covers category/attribute prediction, in-shop retrieval, consumer-to-shop retrieval and landmark detection. MultiModal documents 44,096 high-resolution images and a 12,701-image full-body parsing/keypoint subset; use it only as a future backup for parsing, pose, texture or text experiments. Its annotations are **Documented, not verified locally**. [Original DeepFashion](https://mmlab.ie.cuhk.edu.hk/projects/DeepFashion.html) · [DeepFashion-MultiModal](https://github.com/yumingj/DeepFashion-MultiModal)

## Open decisions

1. Project lead and ML team: approve Fashionpedia's 27 garment categories as primary and 19 part categories as secondary.
2. Dataset owner: verify Fashionpedia training annotations after download.
3. Project lead: decide whether DeepFashion-MultiModal adds enough value for M1; current default is to keep it as backup.
4. Project lead and ML team: approve any future cross-dataset category mapping; current default is no mapping in M1.
5. Repository owner: confirm final paths when the instructor sends the repository.

## Polyvore fallback

Access is currently approved. If it is later revoked or the files cannot be used, continue metadata-only exploration with the original Polyvore dataset and remove compatibility-model training from M1. The project lead owns that scope decision. [Original Polyvore dataset](https://github.com/xthan/polyvore-dataset)

## Page cleanup

Delete the stray “Official source” and “COVERAGE AND FORMAT” lines and empty `#` / `##` headings. Move **Decision: Backup** directly under DeepFashion-MultiModal. Keep `xthan/polyvore-dataset` only under Original Polyvore and `mvasil/polyvore-outfits` only under Polyvore Outfits.
