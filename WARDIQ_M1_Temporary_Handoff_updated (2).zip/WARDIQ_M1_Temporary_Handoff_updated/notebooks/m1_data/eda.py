import pandas as pd
import numpy as np
from pathlib import Path

RAW = Path("data/manifests/raw_manifest.csv")
df = pd.read_csv(RAW, low_memory=False)

print("Shape:", df.shape)
print("\nColumns:")
print(df.columns.tolist())

print("\nDataset counts:")
print(df["source_dataset"].value_counts())

print("\nSplit counts:")
print(df.groupby(["source_dataset", "source_split"]).size())

print("\nUnique item IDs:", df["item_id"].nunique())
print("Duplicate item IDs:", df["item_id"].duplicated().sum())
print("Exact duplicate rows:", df.duplicated().sum())

print("\nMissing values:")
print(df.isna().sum())

print("\nDimension summary:")
print(
    df.groupby("source_dataset")[["image_width", "image_height"]]
      .agg(["count", "min", "max", "mean"])
)

# Fashion-MNIST class distribution
fm = df[df["source_dataset"] == "Fashion-MNIST"]

print("\nFashion-MNIST category distribution:")
print(fm["category_labels"].value_counts().sort_index())

# Fashionpedia annotation statistics
fp = df[df["source_dataset"] == "Fashionpedia"].copy()

for col in ["annotation_ids", "category_ids", "attribute_ids"]:
    fp[f"n_{col}"] = (
        fp[col]
        .fillna("")
        .astype(str)
        .apply(lambda x: len(x.split(";")) if x else 0)
    )

print("\nFashionpedia annotation statistics:")
print(
    fp[["n_annotation_ids", "n_category_ids", "n_attribute_ids"]]
    .describe()
)

print("\nFashionpedia images with zero annotations:")
print((fp["n_annotation_ids"] == 0).sum())

# Duplicate/reference checks
print("\nDuplicate source identity records:")
print(
    df.duplicated(
        ["source_dataset", "source_split", "source_index"]
    ).sum()
)

print("\nDuplicate source image IDs:")
print(
    df.duplicated(
        ["source_dataset", "source_split", "source_image_id"]
    ).sum()
)

print("\nDuplicate original image references:")
print(df.duplicated(["original_image_reference"]).sum())

# Reference availability
def direct_reference_exists(x):
    if "::index=" in str(x):
        return None
    return Path(str(x)).exists()

df["direct_reference_exists"] = df["original_image_reference"].apply(
    direct_reference_exists
)

print("\nDirect filesystem references:")
print(df["direct_reference_exists"].value_counts(dropna=False))

print("\nNOTE:")
print(
    "None indicates an archive/index-style reference such as the "
    "Fashion-MNIST IDX representation. False does not by itself mean "
    "the dataset record is invalid because the complete raw datasets "
    "are not included in this temporary handoff."
)
