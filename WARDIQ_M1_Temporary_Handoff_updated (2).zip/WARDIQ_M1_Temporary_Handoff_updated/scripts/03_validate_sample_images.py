from pathlib import Path
from PIL import Image
import pandas as pd

ROOT = Path("data/samples")

rows = []

files = [
    p for p in ROOT.rglob("*")
    if p.is_file() and p.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"}
]

print(f"Found {len(files)} image files.")

for path in files:
    row = {
        "path": str(path),
        "dataset": path.parts[path.parts.index("samples") + 1]
        if "samples" in path.parts else "unknown",
        "valid": False,
        "width": None,
        "height": None,
        "format": None,
        "mode": None,
        "error": ""
    }

    try:
        with Image.open(path) as img:
            img.verify()

        with Image.open(path) as img:
            row["width"], row["height"] = img.size
            row["format"] = img.format
            row["mode"] = img.mode

        row["valid"] = True

    except Exception as e:
        row["error"] = str(e)

    rows.append(row)

df = pd.DataFrame(rows)

Path("reports/m1").mkdir(parents=True, exist_ok=True)

df.to_csv(
    "reports/m1/sample_image_validation.csv",
    index=False
)

print("\n=== SUMMARY ===")
print("Total:", len(df))
print("Valid:", df["valid"].sum())
print("Invalid:", (~df["valid"]).sum())

print("\n=== BY DATASET ===")
print(
    df.groupby("dataset")["valid"]
    .agg(["count", "sum"])
    .to_string()
)

print("\n=== INVALID FILES ===")
print(
    df.loc[~df["valid"], ["path", "error"]]
    .to_string(index=False)
)

print("\nSaved:")
print("reports/m1/sample_image_validation.csv")
