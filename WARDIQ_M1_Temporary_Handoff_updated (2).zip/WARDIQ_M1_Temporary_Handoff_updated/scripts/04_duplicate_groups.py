from pathlib import Path
import pandas as pd

manifest = Path("data/manifests/raw_manifest.csv")
output = Path("data/manifests/duplicate_groups.csv")

df = pd.read_csv(manifest, low_memory=False)

groups = []

# Exact duplicate rows
dup_rows = df[df.duplicated(keep=False)].copy()
if not dup_rows.empty:
    dup_rows["duplicate_type"] = "exact_manifest_row"
    dup_rows["duplicate_group_key"] = (
        "exact_row_" + dup_rows.groupby(list(df.columns), dropna=False).ngroup().astype(str)
    )
    groups.append(
        dup_rows[
            ["duplicate_type", "duplicate_group_key", "item_id",
             "source_dataset", "source_split",
             "source_index", "source_image_id",
             "original_image_reference"]
        ]
    )

# Duplicate source identity
dup_source = df[
    df.duplicated(
        ["source_dataset", "source_split", "source_index"],
        keep=False
    )
].copy()

if not dup_source.empty:
    dup_source["duplicate_type"] = "source_identity"
    dup_source["duplicate_group_key"] = (
        dup_source["source_dataset"].astype(str)
        + "|"
        + dup_source["source_split"].astype(str)
        + "|"
        + dup_source["source_index"].astype(str)
    )
    groups.append(
        dup_source[
            ["duplicate_type", "duplicate_group_key", "item_id",
             "source_dataset", "source_split",
             "source_index", "source_image_id",
             "original_image_reference"]
        ]
    )

# Duplicate source image IDs
dup_image = df[
    df.duplicated(
        ["source_dataset", "source_split", "source_image_id"],
        keep=False
    )
].copy()

if not dup_image.empty:
    dup_image["duplicate_type"] = "source_image_id"
    dup_image["duplicate_group_key"] = (
        dup_image["source_dataset"].astype(str)
        + "|"
        + dup_image["source_split"].astype(str)
        + "|"
        + dup_image["source_image_id"].astype(str)
    )
    groups.append(
        dup_image[
            ["duplicate_type", "duplicate_group_key", "item_id",
             "source_dataset", "source_split",
             "source_index", "source_image_id",
             "original_image_reference"]
        ]
    )

if groups:
    result = pd.concat(groups, ignore_index=True)
else:
    result = pd.DataFrame(
        columns=[
            "duplicate_type",
            "duplicate_group_key",
            "item_id",
            "source_dataset",
            "source_split",
            "source_index",
            "source_image_id",
            "original_image_reference",
        ]
    )

output.parent.mkdir(parents=True, exist_ok=True)
result.to_csv(output, index=False)

print("Duplicate groups written to:", output)
print("Rows:", len(result))
print("Groups:", result["duplicate_group_key"].nunique() if len(result) else 0)
